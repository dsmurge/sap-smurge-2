// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Which of the following function of String object returns the calling string value converted to upper case while respecting the current locale?",
    answer: "toLocaleUpperCase()",
    options: [
      "toLocaleUpperCase()",
      "toUpperCase()",
      "toString",
      "substring"
    ]
  },
    {
    numb: 2,
    question: "Which of the following function of String object is used to match a regular expression against a string?",
    answer: "match()",
    options: [
      "concat()",
      "match()",
      "search()",
      "replace()"
    ]
  },
    {
    numb: 3,
    question: "What language defines the behavior of a web page?",
    answer: "JavaScript",
    options: [
      "HTML",
      "CSS",
      "XML",
      "JavaScript"
    ]
  },
    {
    numb: 4,
    question: "Which of the following function of Array object creates a new array with the results of calling a provided function on every element in this array?",
    answer: "map()",
    options: [
      "push()",
      "join()",
      "map()",
      "pop()"
    ]
  },
    {
    numb: 5,
    question: "Which built-in method calls a function for each element in the array?",
    answer: "forEach()",
    options: [
      "while()",
      "forEach()",
      "loop()",
      "none"
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];