// 1. Write a JavaScript function which accepts an argument and returns the type.

// function detect_data_type(value)
// {
// let dtypes = [Function, RegExp, Number, String, Boolean, Object], x, len;   
// if (typeof value === "object" || typeof value === "function") 
//     {
//      for (x = 0, len = dtypes.length; x < len; x++) 
//      {
//             if (value instanceof dtypes[x])
//             {
//                 return dtypes[x];
//             }
//       }
//     }
//     return typeof value;
// }
// console.log(detect_data_type(1));
// console.log(detect_data_type(false));




// 2. Write a JavaScript function that accepts a number as a parameter and check the number is prime or not. 
// Note : A prime number (or a prime) is a natural number greater than 1 that has no positive divisors other than 1 and itself.
// Hint : Remember that we used % to check if number can divide without a remainder. You will probably need to use a for..loop.

// function test_prime(p)
// {
//   if (p===1)
//   {
//     return false;
//   }
//   else if(p === 2)
//   {
//     return true;
//   }else
//   {
//     for(var x = 2; x < p; x++)
//     {
//       if(p % x === 0)
//       {
//         return false;
//       }
//     }
//     return true;  
//   }
// }
// console.log(test_prime());




// 3. Write a JavaScript function to convert an amount to small coins.
// Note: Coins are 1,2,5,10,20,50

// function amountTocoins(amount, coins) 
// {
//  if (amount === 0) 
//   {
//      return [];
//    } 
//  else
//    {
//      if (amount >= coins[0]) 
//        {
//         left = (amount - coins[0]);
//         return [coins[0]].concat( amountTocoins(left, coins) );
//         } 
//       else
//         {
//          coins.shift();
//          return amountTocoins(amount, coins);
//         }
//     }
// } 
// console.log(amountTocoins(86, [50, 20, 10, 5, 2, 1]));




// 4. Write a JavaScript program to get the integers in range (x, y)
// Example : range(2, 9)
// Expected Output : [3, 4, 5, 6, 7, 8]
// let range = function(start_num, end_num) 
// {
//   if (end_num - start_num === 2) 
//   {
//     return [start_num + 1];
//   } 
//   else 
//   {
//     let list = range(start_num, end_num - 1);
//     list.push(end_num - 1);
//     return list;
//   }
// };
// console.log(range(2,9));




// // 5. Write a JavaScript program that accept three integers and display the larger
// function max_of_three(a, b, c) 
//  {
//   max_val = 0;
//   if (a > b)
//   {
//     max_val = a;
//   } else
//   {
//     max_val = b;
//   }
//   if (c > max_val) 
//   {
//     max_val = c;
//   }
//   return max_val;
// }
// console.log(max_of_three(10,35,0));



// 6. Write a JavaScript conditional statement to find the sign of product of three numbers. Display an alert box with the specified sign.
// Sample numbers : 3, -7, 2
// Output : The sign is -
// let a=3;
// let b=-7;
// let c=2;
// if (a>0 && b>0 && c>0)
// {
//        alert("The sign is +");
// }
// else if (a<0 && b<0 && c<0)
//         {
//           console.log("The sign is -");
//         }
//         else if (a>0 && b<0 && c<0)
//         {
//           console.log("The sign is +");
//         }
//         else if (a<0 && b>0 && c<0)
//         {
//           console.log("The sign is +");
//         }
//         else
//         {
//           console.log("The sign is -");
//         }


