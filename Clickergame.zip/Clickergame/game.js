//initial number of cookies    
let num = 0;

window.onload = function () {
        let name = prompt("What is your name");
        let space = document.getElementById("space");
        space.innerHTML = name + "'s Bakery";
}

let cookie = document.getElementById("cookie");
function cookieClick() { 
    num += 1;
    let numbers = document.getElementById("numbers");
    //upgrade level for printing
    let upgradeLevel = document.getElementById("upgradeLevel");
    numbers.innerHTML = num; 

    //automatic upgrade
    if(num >= 40 ){
        num += 2;
        upgradeLevel.innerHTML = "Good job";
    }

    //automatic upgrade 
    if(num >= 100) {
        num += 10;
        upgradeLevel.innerHTML = "You are a guru!";
    }

    //automatic upgrade
    if(num >= 500) {
        num += 30;
        upgradeLevel.innerHTML = "You win!";
    }
    
}
// $(function(){
//     doUnknownAnimation();
//     $("div").fadeOut("slow");
// });

// function doUnknownAnimation(){
//     $("div").animate({top: 200, left: 300}, "slow");
// }
  
  




